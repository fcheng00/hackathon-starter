$(document).ready(() => {

  // Place JavaScript code here...

});
